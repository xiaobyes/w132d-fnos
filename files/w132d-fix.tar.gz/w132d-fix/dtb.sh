#!/bin/sh
# W132D 设备树（DTB）更新
# 原因：v12 用的还是 E20C 的设备树，里面根本没有 vop / hdmi / phy / display-subsystem 节点。
#       光装驱动模块，内核找不到显示控制器，HDMI 永远不会亮。
#       另外 led-lan（GPIO4_B5）在旧树里是 default-state=off，会把 USB HUB 摁在复位态。
# 做法：把验证过的 W132D 设备树写进 /boot 的 dtb 目录，原文件备份为 .bak-v12。
#       这份树包含：显示链路(vop/hdmi/phy)、SDIO WiFi 控制器与上电时序、
#       led-lan 默认输出高（释放 USB HUB 复位）。
set -u

HERE=$(cd "$(dirname "$0")" && pwd)
NEW=$HERE/dtb-rk3528-w132d.dtb

if [ ! -f "$NEW" ]; then
    echo "!! 包内缺 dtb-rk3528-w132d.dtb"
    exit 1
fi

# ---- 1. 找 BOOT 分区里的 dtb 目录 ----
DIR=""
for d in /boot/dtb/rockchip /boot/dtb /dtb/rockchip /dtb; do
    if [ -d "$d" ]; then DIR=$d; break; fi
done
if [ -z "$DIR" ]; then
    echo "!! 找不到 dtb 目录，请手动执行： ls /boot"
    exit 1
fi
echo "dtb 目录 : $DIR"

# ---- 2. 找出正在使用的那一个 ----
# dtb 文件头第 4~7 字节大端 = totalsize，和正在运行的 /sys/firmware/fdt 一致
total() {
    od -An -tu1 -j4 -N4 "$1" 2>/dev/null | awk 'NF>=4 {print $1*16777216+$2*65536+$3*256+$4}'
}

CUR=""
if [ -r /sys/firmware/fdt ]; then
    CUR=$(total /sys/firmware/fdt)
fi
echo "运行中 dtb totalsize : ${CUR:-读不到}"

TARGET=""
if [ -n "$CUR" ]; then
    for f in "$DIR"/*.dtb; do
        [ -f "$f" ] || continue
        if [ "$(total "$f")" = "$CUR" ]; then
            TARGET=$f
            break
        fi
    done
fi
if [ -z "$TARGET" ]; then
    echo "（按大小没匹配上，改用固定文件名）"
    TARGET=$DIR/rk3528-radxa-e24c.dtb
fi
echo "将替换   : $TARGET"

if [ ! -f "$TARGET" ]; then
    echo "!! 目标文件不存在，中止。请把上面 'dtb 目录' 下的文件列表发我。"
    ls -l "$DIR" 2>/dev/null
    exit 1
fi

# ---- 3. 备份 + 覆盖 ----
if [ ! -f "$TARGET.bak-v12" ]; then
    cp -f "$TARGET" "$TARGET.bak-v12" && echo "已备份原设备树 -> $TARGET.bak-v12"
fi
cp -f "$NEW" "$TARGET.new" || exit 1
mv -f "$TARGET.new" "$TARGET"  || exit 1
sync

echo "已写入   : $(wc -c < "$TARGET") 字节（新树 $(wc -c < "$NEW") 字节）"

# ---- 4. 简单校验：确认新树里带显示节点 ----
if grep -aq "rockchip,rk3528-hdmi-phy" "$TARGET"; then
    echo "校验通过 : 新设备树含 HDMI PHY 节点"
else
    echo "!! 校验失败：新设备树里没找到 HDMI PHY 字符串"
    exit 1
fi

echo ""
echo "== 设备树已更新，重启后生效 =="
echo "还原方法： cp -f $TARGET.bak-v12 $TARGET"
