#!/bin/sh
# W132D 状态检查（只读，不改任何东西）
set -u

echo "===== 1. 内核 ====="
uname -r
echo ""

echo "===== 2. 设备树里有没有显示节点 ====="
DT=/proc/device-tree
for p in /soc/vop@ff840000 /soc/hdmi@ff8d0000 /soc/phy@ffe00000 /display-subsystem; do
    if [ -e "$DT$p" ]; then echo "  有  $p"; else echo "  缺  $p"; fi
done
echo ""

echo "===== 3. 显示驱动绑定 ====="
for d in ff840000.vop ff8d0000.hdmi ffe00000.phy; do
    printf "  %-16s " "$d"
    if [ -e "/sys/bus/platform/devices/$d/driver" ]; then echo "已绑定"; else echo "未绑定"; fi
done
echo "  DRM 节点:"
ls /sys/class/drm/ 2>/dev/null | sed 's/^/    /' || echo "    (无)"
echo ""

echo "===== 4. USB ====="
if command -v lsusb >/dev/null 2>&1; then
    lsusb -t 2>/dev/null
else
    ls /sys/bus/usb/devices/
fi
echo "  GPIO4_B5 (HUB 复位) 状态:"
if [ -r /sys/kernel/debug/gpio ]; then
    grep -E "gpio-14[01]|green:lan" /sys/kernel/debug/gpio | sed 's/^/    /'
else
    cat /sys/class/leds/green:lan/brightness 2>/dev/null | sed 's/^/    green:lan brightness = /'
fi
echo ""

echo "===== 5. WiFi ====="
ip -br link 2>/dev/null | grep -E "wlan|eth" | sed 's/^/  /'
echo "  已加载模块:"
lsmod 2>/dev/null | grep -E "sprdwl|uwe5622" | sed 's/^/    /' || echo "    (无)"
echo "  SDIO 设备:"
ls /sys/bus/sdio/devices/ 2>/dev/null | sed 's/^/    /' || echo "    (空)"
echo "  uwe-bsp 设备树节点:"
if [ -e /proc/device-tree/uwe-bsp ] || [ -e /sys/firmware/devicetree/base/uwe-bsp ]; then
    echo "    有"
else
    echo "    没有（新设备树没生效，WiFi 加载会崩，先重启）"
fi
echo "  本次开机内核 Oops:"
if dmesg 2>/dev/null | grep -q "Internal error: Oops"; then
    echo "    有 —— 建议断电重启一次"
else
    echo "    无"
fi
echo ""

echo "===== 6. 显示驱动模块位置 ====="
K=$(uname -r)
ls -l /lib/modules/$K/updates/*.ko 2>/dev/null | sed 's/^/  /' || echo "  updates/ 里没有 .ko"
ls -l /lib/modules/$K/extra/*.ko 2>/dev/null | sed 's/^/  /' || echo "  extra/ 里没有 .ko"
echo "  开机自动加载配置:"
if [ -f /etc/modules-load.d/w132d-hdmi.conf ]; then
    sed 's/^/    /' /etc/modules-load.d/w132d-hdmi.conf
else
    echo "    没有 /etc/modules-load.d/w132d-hdmi.conf（重启后 HDMI 不会自动起来）"
fi
if systemctl is-enabled w132d-hdmi.service >/dev/null 2>&1; then
    echo "    w132d-hdmi.service: 已设开机自启"
else
    echo "    w132d-hdmi.service: 没启用"
fi
if [ -f /var/log/w132d-hdmi.log ]; then
    echo "    最近一次开机加载记录:"
    tail -6 /var/log/w132d-hdmi.log | sed 's/^/      /'
fi
echo ""

echo "===== 7. 升级屏蔽是否生效 ====="
if grep -q "w132d upgrade block" /etc/hosts 2>/dev/null; then
    echo "  hosts 屏蔽规则: 有"
else
    echo "  hosts 屏蔽规则: 没有"
fi
ls -l /etc/apt/preferences.d/99-w132d-noupgrade 2>/dev/null | sed 's/^/  /' || echo "  apt pin: 没有"
echo ""

echo "===== 检查完毕 ====="
