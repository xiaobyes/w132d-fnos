#!/bin/sh
# W132D WiFi（展锐 UWE5621DS / Marlin3E）修复
# 做法：装上已编好的两个模块 + 固件 + 校准 INI。
# 三个坑（都已在下面处理好）：
#   1) 驱动的 INI 路径是硬编码的 /lib/firmware/wifi_56630001_3ant.ini，
#      而安装脚本原来把它放进 /lib/firmware/uwe5622/ —— 少一层目录就会
#      报 LOAD_INI_DATA_FAILED 然后复位。所以两个位置都放。
#   2) 设备树必须先生效。sprdwl_ng 启动时要向 uwe5622(BSP) 取总线操作句柄，
#      而 BSP 是靠设备树里的 /uwe-bsp 节点找到 SDIO 控制器的。
#      设备树还是旧的（没有 uwe-bsp）时硬加载，取到的是空指针，
#      内核直接报 Internal error: Oops: 0000000096000004 —— 这就是"装完崩"的真因。
#      → 本脚本先查设备树，没生效就跳过（重启后系统会自己加载，不用再跑）。
#   3) 不要反复 modprobe -r，厂商代码在"初始化失败 + 立即卸载"路径上有悬空指针，也会 Oops。
set -u

HERE=$(cd "$(dirname "$0")" && pwd)
K=$(uname -r)
M=/lib/modules/$K
E=$M/extra
F=/lib/firmware

echo "内核版本 : $K"
if [ ! -d "$M" ]; then
    echo "!! 找不到 $M，内核版本不匹配，停止。"
    exit 1
fi

# 覆盖正在运行的 .ko 会 ETXTBSY，所以先写临时文件再 mv（rename 不受占用影响）
put() {
    install -m 644 "$1" "$2.tmp" && mv -f "$2.tmp" "$2"
}

# ---------------- 预检查 ----------------
echo "== 预检查 =="

# 本次开机是否已经 Oops 过（脏内核里再加载只会继续崩）
if dmesg 2>/dev/null | grep -q "Internal error: Oops"; then
    echo "  内核状态 : 本次开机已出现过 Oops"
    echo ""
    echo "!! 内核已经崩过一次，驱动处于脏状态，现在再加载只会继续崩。"
    echo "   请先重启（断电重启最稳），重启后再跑 6 检查状态 或 3 本项。"
    echo "   本项已跳过，其它项不受影响。"
    exit 0
fi
echo "  内核状态 : 干净"

# 设备树里有没有 /uwe-bsp 节点（BSP 靠它找 SDIO 控制器）
DT=0
for p in /proc/device-tree/uwe-bsp /sys/firmware/devicetree/base/uwe-bsp; do
    if [ -e "$p" ]; then DT=1; fi
done
if [ "$DT" = "1" ]; then
    echo "  设备树   : 有 uwe-bsp 节点"
else
    echo "  设备树   : 没有 uwe-bsp 节点（还是旧树）"
    echo ""
    echo "!! 新设备树还没生效。现在加载 WiFi 驱动，厂商代码会空指针崩"
    echo "   （就是之前那个 Internal error: Oops: 0000000096000004）。"
    echo ""
    echo "   正确顺序是："
    echo "     1) 跑 1 号（或 5 号）换好设备树"
    echo "     2) 重启一次，让新设备树生效"
    echo "     3) 重启后 WiFi 会由系统按硬件自动加载，不用再跑本项"
    echo ""
    echo "   本项已跳过，模块和固件都已放好，重启就够了。"
    exit 0
fi

# ---------------- 安装文件 ----------------
echo "== 安装模块到 $E =="
mkdir -p "$E"
put "$HERE/ko/uwe5622_bsp_sdio.ko" "$E/uwe5622_bsp_sdio.ko" || exit 1
put "$HERE/ko/sprdwl_ng.ko"        "$E/sprdwl_ng.ko"        || exit 1
ls -l "$E"

echo "== 安装固件与校准文件 =="
mkdir -p "$F/uwe5622"
install -m 644 "$HERE/fw/wifi_56630001_3ant.ini" "$F/wifi_56630001_3ant.ini"
install -m 644 "$HERE/fw/wifi_56630001_3ant.ini" "$F/uwe5622/wifi_56630001_3ant.ini"
if [ ! -f "$F/uwe5622/wcnmodem.bin" ]; then
    install -m 644 "$HERE/fw/wcnmodem-marlin3e.bin" "$F/uwe5622/wcnmodem.bin"
fi
if [ ! -f "$F/uwe5622/wcnmodem-marlin3e.bin" ]; then
    install -m 644 "$HERE/fw/wcnmodem-marlin3e.bin" "$F/uwe5622/wcnmodem-marlin3e.bin"
fi
ls -l "$F/wifi_56630001_3ant.ini"
ls -l "$F/uwe5622/"

echo "== 更新模块依赖表 =="
depmod -a "$K" 2>/dev/null || true

# ---------------- 加载 ----------------
echo "== 加载模块 =="
if lsmod 2>/dev/null | grep -q "^uwe5622_bsp_sdio"; then
    echo "  uwe5622_bsp_sdio 已在运行，跳过"
else
    # insmod 走明确路径，避免 modprobe 按依赖表挑到别的副本
    insmod "$E/uwe5622_bsp_sdio.ko" 2>/dev/null \
        || modprobe uwe5622_bsp_sdio 2>/dev/null \
        || echo "  !! uwe5622_bsp_sdio 没装进去"
fi

# 等 SDIO 卡绑定到 sdiohal 驱动 —— 这是 sprdwl_ng 不崩的前提
i=0
BOUND=0
while [ "$i" -lt 15 ]; do
    if ls /sys/bus/sdio/drivers/sdiohal/ 2>/dev/null | grep -q ":"; then
        BOUND=1
        break
    fi
    sleep 1
    i=$((i + 1))
done

if [ "$BOUND" != "1" ]; then
    echo ""
    echo "!! SDIO 卡没有绑定到 sdiohal 驱动，跳过加载 sprdwl_ng。"
    echo "   这种情况下再往下加载，sprdwl_ng 会在初始化时空指针崩（Oops），所以主动停手。"
    echo ""
    echo "   SDIO 设备列表:"
    ls /sys/bus/sdio/devices/ 2>/dev/null | sed 's/^/     /' || echo "     (空)"
    echo "   最近相关日志:"
    dmesg 2>/dev/null | grep -iE "sdiohal|mmc2|sdio|uwe" | tail -10 | sed 's/^/     /'
    echo ""
    echo "   多数情况重启一次就好；重启后仍不行，把上面日志发我。"
    exit 0
fi
echo "  SDIO 已绑定 sdiohal : 是"

if lsmod 2>/dev/null | grep -q "^sprdwl_ng"; then
    echo "  sprdwl_ng 已在运行，跳过"
else
    insmod "$E/sprdwl_ng.ko" 2>/dev/null || modprobe sprdwl_ng 2>/dev/null || true
fi
sleep 4

echo "== 结果 =="
lsmod 2>/dev/null | grep -E "sprdwl|uwe5622" || echo "  (模块没加载上)"
echo "--- 网络接口 ---"
ip -br link 2>/dev/null | grep -E "wlan|eth" || ip -br link
echo "--- 内核日志 ---"
dmesg 2>/dev/null | grep -iE "ini path|open file|wlan0|download finished" | tail -8

echo ""
if dmesg 2>/dev/null | grep -q "Internal error: Oops"; then
    echo "!! 出现了内核 Oops —— 断电重启一次，重启后 WiFi 会自动加载。"
    echo ""
fi
echo "== 完成 =="
echo "看到 wlan0 就成了。连网："
echo "  nmcli dev wifi list"
echo "  nmcli dev wifi connect \"你的SSID\" password \"你的密码\""
echo "看不到 wlan0 且上面写了 Oops：断电重启，重启后系统会自己加载，别重复跑本项。"
