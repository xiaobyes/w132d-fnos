#!/bin/sh
# W132D 系统升级屏蔽（幂等，可反复执行）
# 升级会覆盖 boot.scr / dtb / 内核 -> 直接失联，所以从"下载"这一步掐断
MARK="# w132d upgrade block"
HOSTS=/etc/hosts
CACHE=/etc/w132d-update-domains.txt

mkdir -p /etc/w132d /etc/apt/preferences.d 2>/dev/null

# ---- apt 层：内核/引导包永远装不上 ----
if [ ! -f /etc/apt/preferences.d/99-w132d-noupgrade ]; then
    cat > /etc/apt/preferences.d/99-w132d-noupgrade << 'EOP'
Package: linux-image* linux-headers* linux-dtb* u-boot* uboot* fnos-kernel* trim-kernel* linux-libc-dev
Pin: release *
Pin-Priority: -1
EOP
fi

# ---- 关掉自动更新定时器（mask = 指向 /dev/null）----
for u in apt-daily.timer apt-daily.service apt-daily-upgrade.timer \
         apt-daily-upgrade.service unattended-upgrades.service; do
    [ -L "/etc/systemd/system/$u" ] || ln -sf /dev/null "/etc/systemd/system/$u" 2>/dev/null
done

# ---- 域名：从 trim 程序里挖一次，缓存起来 ----
if [ ! -s "$CACHE" ]; then
    T=/tmp/.w132d-dom.$$
    for f in /usr/trim/bin/* /usr/trim/sbin/*; do
        [ -f "$f" ] || continue
        strings -a "$f" 2>/dev/null | grep -oE 'https?://[a-zA-Z0-9._-]+' | sed 's|https\?://||'
    done | sort -u > "$T" 2>/dev/null
    grep -iE 'updat|upgrad|ota|^dl\.|download|repo|pkg' "$T" > "$CACHE" 2>/dev/null
    [ -s "$CACHE" ] || echo "# none" > "$CACHE"
    rm -f "$T"
fi

# ---- hosts 屏蔽（只写一次）----
if ! grep -qF "$MARK" "$HOSTS" 2>/dev/null; then
    {
        echo "$MARK"
        grep -v '^#' "$CACHE" | grep -v '^$' | sed 's/^/0.0.0.0 /'
        echo "# w132d upgrade block end"
    } >> "$HOSTS"
fi

exit 0
