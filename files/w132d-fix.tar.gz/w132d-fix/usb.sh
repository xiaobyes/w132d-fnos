#!/bin/sh
# W132D USB2 三个口修复
# 原因：GM8220S 四口 HUB 的复位脚是 GPIO4_B5（低有效，需输出高）。
#       DTB 里 green:lan 这个 LED 也声明在同一引脚上，gpio-leds 抢到引脚后
#       按 default-state=off 把它拉低 -> HUB 一直处在复位态 -> 三个 USB2 口全不枚举。
#       （靠近 HDMI 的那个蓝口走 USB3，不经 HUB，所以一直是好的。）
# 做法：把 green:lan 的 brightness 置 1，即 GPIO4_B5 输出高，复位释放。
#       并用 udev 规则 + systemd 服务双保险，保证每次开机自动执行。
set -u

LED=/sys/class/leds/green:lan

echo "== 立即生效 =="
if [ -e "$LED/brightness" ]; then
    echo 1 > "$LED/brightness"
    echo "已拉高 GPIO4_B5（$LED brightness=1）"
else
    echo "!! 没找到 $LED，下面列出现有 LED："
    ls /sys/class/leds/ 2>/dev/null
fi

echo "== 安装 udev 规则 =="
mkdir -p /etc/udev/rules.d
cat > /etc/udev/rules.d/99-w132d-usbhub.rules << 'EOR'
ACTION=="add|change", SUBSYSTEM=="leds", KERNEL=="green:lan", RUN+="/bin/sh -c 'echo 1 > /sys/class/leds/green:lan/brightness'"
EOR

echo "== 安装 systemd 兜底服务 =="
cat > /usr/local/sbin/w132d-usbhub.sh << 'EOS'
#!/bin/sh
for i in $(seq 1 100); do
    if [ -e /sys/class/leds/green:lan/brightness ]; then
        echo 1 > /sys/class/leds/green:lan/brightness
        exit 0
    fi
    sleep 0.2
done
exit 1
EOS
chmod 755 /usr/local/sbin/w132d-usbhub.sh

cat > /etc/systemd/system/w132d-usbhub.service << 'EOS'
[Unit]
Description=W132D release GM8220S USB hub reset (GPIO4_B5)
After=sysinit.target
Before=multi-user.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/w132d-usbhub.sh
RemainAfterExit=yes

[Install]
WantedBy=multi-user.target
EOS

udevadm control --reload-rules 2>/dev/null || true
systemctl daemon-reload 2>/dev/null || true
systemctl enable w132d-usbhub.service 2>/dev/null && echo "w132d-usbhub.service 已设为开机自启"

echo "== 当前 USB 拓扑 =="
sleep 3
lsusb -t 2>/dev/null || ls /sys/bus/usb/devices/

echo "== 完成。现在把 U 盘插到那三个 USB2 口试试 =="
