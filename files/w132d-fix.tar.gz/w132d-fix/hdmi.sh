#!/bin/sh
# W132D HDMI 显示修复
# 原因：飞牛内核把 inno-hdmi-phy 编进内核了，而内建那份只认 rk3228/rk3328，不认 rk3528。
#       PHY 从不探测 -> 不注册时钟 -> vop 的父时钟永远等不到 -> 显示链路第一级就断，且不报错。
#       自编的 PHY 模块又因为驱动名 inno-hdmi-phy 与内建重名，在 driver_register 阶段 -EEXIST。
# 做法：自编 PHY 模块（内部驱动名 rk3528-hdmi-phy，绕开重名）+ 自编 rockchipdrm，
#       一起放进 /lib/modules/<ver>/updates/，updates 优先级高于 kernel/。
set -u

HERE=$(cd "$(dirname "$0")" && pwd)
K=$(uname -r)
M=/lib/modules/$K
U=$M/updates
KDRV=$M/kernel/drivers/gpu/drm/rockchip

echo "内核版本 : $K"
if [ ! -d "$M" ]; then
    echo "!! 找不到 $M，内核版本不匹配，停止。"
    echo "   当前内核: $K"
    exit 1
fi

mkdir -p "$U"

# 备份原厂 rockchipdrm.ko（只备份一次，不覆盖已有备份）
if [ -f "$KDRV/rockchipdrm.ko" ] && [ ! -f "$KDRV/rockchipdrm.ko.stock" ]; then
    cp -f "$KDRV/rockchipdrm.ko" "$KDRV/rockchipdrm.ko.stock"
    echo "已备份原厂 rockchipdrm.ko -> rockchipdrm.ko.stock"
fi

# 覆盖正在运行的 .ko 会 ETXTBSY，先写临时文件再 mv（rename 不受占用影响）
put() {
    install -m 644 "$1" "$2.tmp" && mv -f "$2.tmp" "$2"
}

echo "== 安装模块到 $U =="
put "$HERE/ko/rockchipdrm.ko"            "$U/rockchipdrm.ko"            || exit 1
put "$HERE/ko/phy-rockchip-inno-hdmi.ko" "$U/phy-rockchip-inno-hdmi.ko" || exit 1
ls -l "$U"

echo "== 更新模块依赖表 =="
depmod -a "$K" 2>/dev/null || true

# ---------------- 开机自动加载（重启后不失效的关键） ----------------
# PHY 模块是外挂的，内核里没有任何东西会去加载它；而 vop 的父时钟靠它提供，
# 少了它 vop 一直 -EPROBE_DEFER，且不打印任何错误 —— 表现就是"重启后黑屏"。
# 所以必须写进 modules-load.d，并保证顺序：先 PHY，后 rockchipdrm。
echo "== 设置开机自动加载 =="
cat > /etc/modules-load.d/w132d-hdmi.conf << 'EOS'
# W132D HDMI: order matters -- PHY first, then rockchipdrm
phy-rockchip-inno-hdmi
rockchipdrm
EOS
echo "  /etc/modules-load.d/w132d-hdmi.conf 已写入"

cat > /usr/local/sbin/w132d-hdmi-load.sh << 'EOS'
#!/bin/sh
# 兜底：无论如何保证 PHY 先于 rockchipdrm
U=/lib/modules/$(uname -r)/updates
grep -qw phy_rockchip_inno_hdmi /proc/modules || insmod "$U/phy-rockchip-inno-hdmi.ko" 2>/dev/null
grep -qw rockchipdrm /proc/modules || modprobe rockchipdrm 2>/dev/null
{
    echo "=== $(date '+%F %T') w132d-hdmi ==="
    lsmod | grep -E "rockchipdrm|phy_rockchip_inno" || echo "modules: none"
    ls /sys/class/drm/ 2>/dev/null
} >> /var/log/w132d-hdmi.log 2>&1
exit 0
EOS
chmod 755 /usr/local/sbin/w132d-hdmi-load.sh

cat > /etc/systemd/system/w132d-hdmi.service << 'EOS'
[Unit]
Description=W132D load HDMI PHY then rockchipdrm
DefaultDependencies=no
After=local-fs.target systemd-modules-load.service
Before=sysinit.target shutdown.target
Conflicts=shutdown.target

[Service]
Type=oneshot
ExecStart=/usr/local/sbin/w132d-hdmi-load.sh
RemainAfterExit=yes

[Install]
WantedBy=sysinit.target
EOS
systemctl daemon-reload 2>/dev/null || true
systemctl enable w132d-hdmi.service 2>/dev/null && echo "  w132d-hdmi.service 已设为开机自启"

echo "== 重新加载显示驱动（当前会话立即生效）=="
modprobe -r rockchipdrm 2>/dev/null || true
insmod "$U/phy-rockchip-inno-hdmi.ko" 2>/dev/null \
    && echo "PHY 模块已加载" \
    || echo "PHY insmod 跳过（可能已被内建驱动占用，属正常）"
modprobe rockchipdrm 2>/dev/null || insmod "$U/rockchipdrm.ko" 2>/dev/null || true
sleep 2

echo "== 绑定情况 =="
for d in ff840000.vop ff8d0000.hdmi ffe00000.phy; do
    printf "  %-16s " "$d"
    if [ -e "/sys/bus/platform/devices/$d/driver" ]; then
        echo "已绑定"
    else
        echo "未绑定"
    fi
done

echo "== DRM 节点 =="
ls /sys/class/drm/ 2>/dev/null || echo "  (没有 /sys/class/drm)"

echo "== 完成 =="
echo "模块、设备树、开机自启都装好了。现在重启一次（跑 2 号），重启后 HDMI 自动起来。"
echo "重启后如果还黑屏，看 /var/log/w132d-hdmi.log 或跑 6 号检查。"
