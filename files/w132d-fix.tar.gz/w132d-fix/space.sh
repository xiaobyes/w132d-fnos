#!/bin/sh
# W132D 划出未分配空间，留给飞牛后台建存储空间
# 用法:  sh space.sh <要留出的 GB 数>
#
# 原理：飞牛首启会把根分区扩到整块 eMMC 的 99%，系统盘吃满，
#       后台就永远建不了存储空间。这里做两件事：
#         1) btrfs 根文件系统在线缩减
#         2) 分区 2 的结束位置往前收，尾巴空出来
#       btrfs 必须先缩，分区后缩（顺序反了会丢数据）。
#       空出来的未分配空间，去 飞牛后台 - 存储空间 - 创建 里用。
set -u

SYS=${SYSDIR:-/sys/class/block}

WANT=${1:-10}
MIN_ROOT_GB=${MIN_ROOT_GB:-12}

echo "============================================================"
echo "  W132D  划出存储空间"
echo "============================================================"
echo "  要留出的空间 : ${WANT} GB"
echo ""

case "$WANT" in
'' | *[!0-9]*)
    echo "!! 参数不是整数：$WANT"
    exit 1
    ;;
esac
if [ "$WANT" -lt 1 ] || [ "$WANT" -gt 100 ]; then
    echo "!! 参数超出范围：${WANT} GB"
    exit 1
fi

# ---------------- 1. 定位根分区 ----------------
ROOTDEV=$(findmnt -n -o SOURCE / 2>/dev/null)
[ -z "$ROOTDEV" ] && ROOTDEV=$(awk '$2=="/"{print $1}' /proc/mounts)
ROOTFS=$(findmnt -n -o FSTYPE / 2>/dev/null)
[ -z "$ROOTFS" ] && ROOTFS=unknown

echo "  根文件系统   : $ROOTDEV  ($ROOTFS)"
if [ "$ROOTFS" != "btrfs" ]; then
    echo "!! 根文件系统不是 btrfs（是 $ROOTFS），这个脚本不处理，停止。"
    exit 1
fi

case "$ROOTDEV" in
/dev/mmcblk*p[0-9]*) DISK=${ROOTDEV%p[0-9]*} ;;
/dev/*[0-9]) DISK=${ROOTDEV%[0-9]*} ;;
*)
    echo "!! 认不出根分区对应的磁盘：$ROOTDEV"
    exit 1
    ;;
esac
PART=$(echo "$ROOTDEV" | sed 's/.*[^0-9]\([0-9][0-9]*\)$/\1/')
echo "  磁盘 / 分区  : $DISK  p$PART"

if [ ! -r "$SYS/$(basename "$ROOTDEV")/size" ]; then
    echo "!! 读不到 $SYS/$(basename "$ROOTDEV")，停止。"
    exit 1
fi

START_S=$(cat "$SYS/$(basename "$ROOTDEV")/start")
SIZE_S=$(cat "$SYS/$(basename "$ROOTDEV")/size")
DISK_S=$(cat "$SYS/$(basename "$DISK")/size")

DISK_GB=$((DISK_S / 2097152))
CUR_GBI=$(awk "BEGIN{printf \"%.1f\", $SIZE_S*512/1073741824}")
echo "  整块 eMMC    : ${DISK_GB} GiB"
echo "  根分区现在   : ${CUR_GBI} GiB"
echo ""

# ---------------- 2. 安全校验 ----------------
# 判据：根分区必须是这块盘上"最后一个"分区。
# 不能拿"分区结束位置是否贴着磁盘末尾"当判据 —— 飞牛首启只扩到整盘的 99%，
# 尾部天生就留着约 1% 的未分配空间，用位置差判断会误报。
END_S=$((START_S + SIZE_S))
TAIL_S=$((DISK_S - END_S))
[ "$TAIL_S" -lt 0 ] && TAIL_S=0

BASE=$(basename "$DISK")
LAST=1
for f in "$SYS/$BASE"/"$BASE"p*/start; do
    [ -e "$f" ] || continue
    s=$(cat "$f" 2>/dev/null) || continue
    [ "$s" -ge "$END_S" ] && LAST=0
done
if [ "$LAST" != "1" ]; then
    echo "!! 根分区后面还有别的分区，本脚本不敢动，停止。"
    echo "   分区表："
    lsblk -o NAME,SIZE,TYPE,MOUNTPOINT "$DISK" 2>/dev/null | sed 's/^/     /'
    exit 1
fi

TAIL_MB=$((TAIL_S * 512 / 1048576))
echo "  尾部未分配   : ${TAIL_MB} MB（飞牛首启只扩到整盘 99%，属正常）"

# 目标：划出 WANT GB 的连续未分配空间（含尾部原有的那点余量）
WANT_B=$((WANT * 1073741824))
NEED_CUT_B=$((WANT_B - TAIL_S * 512))
[ "$NEED_CUT_B" -lt 0 ] && NEED_CUT_B=0

NEW_BYTES=$((SIZE_S * 512 - NEED_CUT_B))
NEW_BYTES=$((NEW_BYTES / 1048576 * 1048576))
NEW_GBI=$(awk "BEGIN{printf \"%.1f\", $NEW_BYTES/1073741824}")

if [ "$NEW_BYTES" -le 0 ]; then
    echo "!! 算出来的新分区大小不对，停止。"
    exit 1
fi

if [ $((NEW_BYTES / 1073741824)) -lt "$MIN_ROOT_GB" ]; then
    echo "!! 留 ${WANT} GB 之后根分区只剩 ${NEW_GBI} GiB，"
    echo "   少于安全下限 ${MIN_ROOT_GB} GiB。建议改成 10 GB 或更小。停止。"
    exit 1
fi

echo ""
echo "  计划：根分区 ${CUR_GBI} GiB  ->  ${NEW_GBI} GiB"
echo "        空出 ${WANT} GB 未分配空间给飞牛建存储空间"
echo ""

if ! command -v parted >/dev/null 2>&1; then
    echo "!! 系统里没有 parted，无法改分区表。停止。"
    exit 1
fi

# ---------------- 3. 先缩文件系统 ----------------
echo "== 1/3 缩减 btrfs 根文件系统（在线操作）=="
if btrfs filesystem resize "$NEW_BYTES" / ; then
    echo "   文件系统已缩到 ${NEW_GBI} GiB"
else
    echo "!! btrfs 缩减失败，分区表没动，系统原样。"
    echo "   常见原因：快照/metadata 占用过多，先删点东西再试。"
    exit 1
fi

# ---------------- 4. 再收分区 ----------------
echo ""
echo "== 2/3 收缩分区 ${DISK} p${PART} =="
NEW_END_S=$((START_S + NEW_BYTES / 512 - 1))
NEW_SIZE_S=$((NEW_BYTES / 512))
OK=0
if parted -s "$DISK" unit s resizepart "$PART" "$NEW_END_S" 2>/dev/null; then
    OK=1
    echo "   parted 已把分区结束位置改到扇区 $NEW_END_S"
elif command -v sfdisk >/dev/null 2>&1; then
    echo "   parted 没成功，改用 sfdisk 直接改分区表 ..."
    if echo ",$NEW_SIZE_S" | sfdisk --no-reread --force -N "$PART" "$DISK" 2>/dev/null; then
        OK=1
        echo "   sfdisk 已把分区大小改为 $NEW_SIZE_S 扇区"
    fi
fi

if [ "$OK" != "1" ]; then
    echo "!! 分区收缩失败。文件系统已经变小了（不影响使用），"
    echo "   但分区还没收 —— 重新跑一次本脚本即可，"
    echo "   或者先恢复： btrfs filesystem resize max /"
    exit 1
fi

echo ""
echo "== 3/3 让内核重新读分区表 =="
partprobe "$DISK" 2>/dev/null || partx -u "$DISK" 2>/dev/null || true
sleep 1
blockdev --rereadpt "$DISK" 2>/dev/null || true
sleep 1

# ---------------- 5. 结果 ----------------
echo ""
echo "== 结果 =="
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT "$DISK" 2>/dev/null | sed 's/^/  /'
echo ""
df -h / | sed 's/^/  /'
echo ""
FREE_S=$(cat "$SYS/$(basename "$DISK")/size" 2>/dev/null || echo 0)
END_NOW=$(cat "$SYS/$(basename "$ROOTDEV")/size" 2>/dev/null || echo 0)
START_NOW=$(cat "$SYS/$(basename "$ROOTDEV")/start" 2>/dev/null || echo 0)
LEFT_GB=$(( (FREE_S - START_NOW - END_NOW) * 512 / 1073741824 ))
echo "  未分配空间约 : ${LEFT_GB} GB"
echo ""

# ---------------- 6. 防止下次开机又被自动铺满 ----------------
if [ -f /usr/trim/bin/resize-rootfs.sh ]; then
    if [ ! -f /usr/trim/bin/resize-rootfs.sh.disabled ]; then
        mv /usr/trim/bin/resize-rootfs.sh /usr/trim/bin/resize-rootfs.sh.disabled 2>/dev/null \
            && echo "  已停用自动扩容脚本 /usr/trim/bin/resize-rootfs.sh（改名为 .disabled）" \
            || echo "  !! 停用自动扩容脚本失败（不影响本次结果）"
    else
        echo "  自动扩容脚本早已停用"
    fi
fi

echo ""
echo "============================================================"
echo "  完成。剩下的未分配空间在飞牛后台里这样用："
echo "    浏览器进飞牛后台  ->  存储空间  ->  创建存储空间"
echo "    容量选最大（或按需），文件系统选 btrfs / ext4 都行"
echo ""
echo "  想改大小：重新跑一次本脚本，填一个更大的数（只能收不能放）。"
echo "  想还原自动扩容：mv /usr/trim/bin/resize-rootfs.sh.disabled /usr/trim/bin/resize-rootfs.sh"
echo "============================================================"
